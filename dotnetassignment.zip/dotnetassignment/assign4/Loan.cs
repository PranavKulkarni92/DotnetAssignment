﻿ namespace SBI;

 public abstract class Loan
 {

  private double principle;

  private float period;


  public Loan(double principle,float period)
  {
     this.principle=principle;
     this.period=period;
  }

  public Loan():this(120000,6)
  {

  }

  public double Principle
  {
   set
   {
       principle=value;
   }
   get
   {
      return principle;
   } 

  }
  
    public float Period
  {
    set
    {
       period=value;
    }
    get
    {
       return period;
    }
  }

   
    public abstract double GetRate();


    public double GetEmi()
   {
     
   double rate=GetRate(); 
   return principle*(1+rate*period/100)/(12*period);

   }
    
    
 }
