class curvedbanner:banner{

public double radius { get; set; }


public curvedbanner():base()
{
    radius=0.1f;
}

public curvedbanner(int width,int height,double radius=0.2):base(width,height)
{
 this.radius=radius;
}

public override bool Resize(int width,int height)
{

base.Resize(width,height);
radius=0.2f;
return true;

}


public override double Area()
{

return base.Area()-0.86*radius*radius;

}








}