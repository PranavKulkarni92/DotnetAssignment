using System;
class Program
{

public static void Main(string[] args)
{

int width=int.Parse(args[0]);
int height=int.Parse(args[1]);


banner t=new banner(width,height);

Console.WriteLine("Area of banner-{0}", t.Area());


curvedbanner q=new curvedbanner(width,height);

Console.WriteLine("Area for curverd banne-{0}",q.Area());


}




}